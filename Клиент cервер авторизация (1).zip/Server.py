from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse
from urllib.parse import parse_qs
import os

ServerAddress = '127.0.0.1'
ServerPort = 4445

UsersDB = []
MessagesDB = []

def ReadFile(FileName):
	global UsersDB
	if os.path.exists(FileName):
		with open(FileName, 'r') as File:
			for Line in File:
				if Line.strip(' \t\n\r') == '':
					continue
				UserData = Line.strip().split(';')
				#ListBox1.insert(END, TaskData[0] + ' | ' + TaskData[1].replace('\n', ' ') + '\n')
				UsersDB.append(UserData)
ReadFile('Users.csv')

def WriteUsers(FileName):
	global UsersDB
	with open(FileName, 'w') as File:
		for Line in UsersDB:
			File.write(';'.join(Line) + '\n')

class MyHandler(BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()

    def do_GET(self):
        paths = {
            '/foo': {'status': 200},
            '/bar': {'status': 302},
            '/baz': {'status': 404},
            '/qux': {'status': 500}
        }

        if self.path in paths:
            self.respond(paths[self.path])
        else:
            self.respond({'status': 200})

    def handle_http(self, status_code, path):
        global UsersDB
        self.send_response(status_code)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        
        content = ''
            
        parsed_url = urlparse(path)
        query_params = parse_qs(parsed_url.query)

        # Авторизация
        if 'login' in query_params and 'password' in query_params:
            login = query_params['login'][0]
            password = query_params['password'][0]
            content = 'auth:error'
            for UserData in UsersDB:
                if UserData[0] == login:
                    if UserData[1] == password:
                        content = 'auth:ok'
                        print('Пользователь ' + UserData[0] + ' успешно авторизован')
                        break
           
        # Регистрация
        if 'reglogin' in query_params and 'regpass' in query_params:
            login = query_params['reglogin'][0]
            password = query_params['regpass'][0]
            content = 'reg:error'
            if not any(UserData[0] == login for UserData in UsersDB):
                content = 'reg:ok'
                UsersDB.append([login, password])
                print('Пользователь ' + login + ' успешно зарегистирован')
                WriteUsers('Users.csv')
      
        return bytes(content, 'UTF-8')

    def respond(self, opts):
        response = self.handle_http(opts['status'], self.path)
        self.wfile.write(response)
        
    def log_message(self, format, *args):
        pass

if __name__ == '__main__':
    server_class = HTTPServer
    httpd = server_class((ServerAddress, ServerPort), MyHandler)
    print('Информацоинные технологии')
    print('Сервер запущен - %s:%s' % (ServerAddress, ServerPort))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    httpd.server_close()
    print('Сервер остановлен - %s:%s' % (ServerAddress, ServerPort))
